/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#include <config.h>
#define _GL_STAT_TIME_INLINE _GL_EXTERN_INLINE
#include "stat-time.h"
