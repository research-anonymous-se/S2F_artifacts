# Authors of OpenJPEG
See also [THANKS](https://github.com/uclouvain/openjpeg/blob/master/THANKS.md)

David Janssens designed and implemented the first version of OpenJPEG.

Kaori Hagihara designed and implemented the first version of OpenJPIP.

Jerome Fimes implemented the alpha version of OpenJPEG 2.0.

Giuseppe Baruffa added the JPWL functionalities.

Mickaël Savinaud implemented the final OpenJPEG 2.0 version based on a big merge between 1.5 version and alpha version of 2.0.

Mathieu Malaterre participated to the OpenJPEG 2.0 version and improved the libraries and utilities. 

Yannick Verschueren, 
Herve Drolon, 
Francois-Olivier Devaux, 
Antonin Descampe
    improved the libraries and utilities.

