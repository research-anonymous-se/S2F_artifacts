<!--
IMPORTANT: Do NOT use GitHub to post any questions or support requests!
           They will be closed immediately and ignored.

Questions should go to the OpenJPEG mailing list at
https://groups.google.com/g/openjpeg or other support forums.
GitHub issues are for bug reports and suggestions for new features.

The OpenJPEG project is made of contributions from various individuals and
organizations, each with their own focus. The issue you are facing is
not necessarily in the priority list of those contributors and consequently
there is no guarantee that it will be addressed in a timely manner.

-->

## Expected behavior and actual behavior.

...to fill...

## Steps to reproduce the problem.

...to fill...

## Operating system

...to fill...

## openjpeg version

...to fill...
