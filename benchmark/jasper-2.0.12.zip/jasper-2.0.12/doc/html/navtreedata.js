var NAVTREE =
[
  [ "Reference Manual (Version 2.0.12)", "index.html", [
    [ "Introduction", "index.html#intro", null ],
    [ "License", "index.html#license", null ],
    [ "Reporting Bugs", "index.html#bugs", null ],
    [ "Getting Started", "getting_started.html", "getting_started" ],
    [ "Frequently Asked Questions (FAQ)", "faq.html", null ],
    [ "Known Bugs", "known_bugs.html", null ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"bmp__cod_8h_source.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';